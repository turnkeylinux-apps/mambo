<?php
$auto_publish_comments = "1";
$allow_anonymous_entries = "1";
$notify_new_entries = "0";
$allow_comments_in_sections = "0,4";
$comments_per_page = "10";
$admin_comments_length = "100";
?>